package dkeep.logic;

public final class DungeonMapTest extends DungeonMap {

	public DungeonMapTest(String personality) {
		super(personality);
	}

	@Override
	protected void moveGuard() {
	}

}
